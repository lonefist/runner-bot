# Runner Bot

Telegram bot source using the public DEX Screener API for conservative Solana
"heating up" signals.

## Files
- `runner_bot.py` — supplied Python source.
- `.env.example` — placeholder configuration.
- `README.md` — basic setup notes.

The supplied source ends inside `FreshnessTracker._finish`; no additional bot
logic was invented or added.
