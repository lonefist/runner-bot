"""Telegram bot for conservative, early Solana "heating up" signals.

The bot uses Telegram long polling and the public DEX Screener API. It uses
5-minute transaction counts for directional activity and never treats them as
dollar net flow.
"""

from __future__ import annotations

import json
import logging
import math
import os
import signal
import threading
import time
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from typing import Any
from urllib import error, parse, request

LOGGER = logging.getLogger("runner_bot")

POLL_TIMEOUT_SECONDS = 30
RETRY_DELAY_SECONDS = 5
START_MESSAGE = "Runner bot is online!"
DEX_API_BASE = "https://api.dexscreener.com"
SOLANA_CHAIN = "solana"
DEFAULT_SCAN_INTERVAL_SECONDS = 15
DEFAULT_MAX_TOKENS_PER_SCAN = 200
DEFAULT_ALERT_COOLDOWN_SECONDS = 3_600
MAX_TOKENS_PER_REQUEST = 30

DISCLAIMER = (
    "Disclaimer: For informational purposes only. Not investment advice or a "
    "token advertisement. We accept no responsibility for investment decisions "
    "or losses. Do your own research and make your own investment decisions."
)

@dataclass
class TelegramApiError(Exception):
    """Raised when Telegram returns an unsuccessful API response."""

    method: str
    description: str

    def __str__(self) -> str:
        return f"Telegram API request {self.method!r} failed: {self.description}"

@dataclass
class DexScreenerApiError(Exception):
    """Raised when a DEX Screener request cannot be completed."""

    url: str
    description: str

    def __str__(self) -> str:
        return f"DEX Screener request failed for {self.url}: {self.description}"

@dataclass(frozen=True)
class TokenSnapshot:
    """The source-backed metrics used to decide whether a token is heating up."""

    address: str
    symbol: str
    market_cap_usd: float | None
    liquidity_usd: float | None
    volume_5m_usd: float | None
    price_change_5m_percent: float | None
    buys_5m: int | None
    sells_5m: int | None

    @property
    def transactions_5m(self) -> int | None:
        if self.buys_5m is None or self.sells_5m is None:
            return None
        return self.buys_5m + self.sells_5m

    @property
    def buy_sell_ratio_5m(self) -> float | None:
        if self.buys_5m is None or self.sells_5m is None:
            return None
        if self.sells_5m == 0:
            return float("inf") if self.buys_5m > 0 else None
        return self.buys_5m / self.sells_5m

@dataclass(frozen=True)
class PairFallbackStats:
    """Field availability before and after same-token pair fallback."""

    missing_market_cap: int
    missing_liquidity_before: int
    missing_liquidity_after: int
    missing_price_change_before: int
    missing_price_change_after: int

@dataclass(frozen=True)
class FreshnessObservation:
    """A source-backed metric snapshot for one 7/7 observation."""

    observed_at: str
    market_cap_usd: float | None
    liquidity_usd: float | None
    volume_5m_usd: float | None
    buys_5m: int | None
    sells_5m: int | None
    buy_sell_ratio_5m: float | None
    price_change_5m_percent: float | None

@dataclass
class FreshnessRecord:
    """One uninterrupted 7/7 episode for a token."""

    address: str
    symbol: str
    first_reached_at: str
    consecutive_scans: int
    observations: list[FreshnessObservation]
    active: bool = True
    ended_at: str | None = None
    end_reason: str | None = None

    @property
    def first_observation(self) -> FreshnessObservation:
        return self.observations[0]

    @property
    def final_observation(self) -> FreshnessObservation:
        return self.observations[-1]

def _number(value: Any) -> float | None:
    """Return a finite numeric value without coercing missing data."""

    if isinstance(value, bool) or value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None

def _count(value: Any) -> int | None:
    number = _number(value)
    if number is None or number < 0:
        return None
    return int(number)

def _window(data: Any, name: str) -> dict[str, Any]:
    if not isinstance(data, dict):
        return {}
    value = data.get(name) or data.get(name.replace("m", ""))
    return value if isinstance(value, dict) else {}

def _metric(data: Any, name: str) -> float | None:
    if not isinstance(data, dict):
        return None
    return _number(data.get(name))

def _format_compact_usd(value: float | None) -> str:
    if value is None:
        return "unavailable"
    absolute = abs(value)
    if absolute >= 1_000_000_000:
        return f"{value / 1_000_000_000:.2f}B"
    if absolute >= 1_000_000:
        return f"{value / 1_000_000:.2f}M"
    if absolute >= 1_000:
        return f"{value / 1_000:.2f}K"
    return f"{value:,.2f}"

def snapshot_from_pair(pair: dict[str, Any]) -> TokenSnapshot | None:
    """Convert one DEX Screener pair into a strictly source-backed snapshot."""

    base_token = pair.get("baseToken")
    if not isinstance(base_token, dict):
        return None

    address = base_token.get("address")
    if not isinstance(address, str) or not address:
        return None

    symbol = base_token.get("symbol")
    safe_symbol = str(symbol).strip().replace("$", "") if symbol else "UNKNOWN"
    txns = pair.get("txns")
    txns_5m = _window(txns, "m5")
    volume = pair.get("volume")
    liquidity = pair.get("liquidity")
    price_change = pair.get("priceChange")

    return TokenSnapshot(
        address=address,
        symbol=safe_symbol or "UNKNOWN",
        market_cap_usd=_number(pair.get("marketCap")),
        liquidity_usd=_metric(liquidity, "usd"),
        volume_5m_usd=_metric(volume, "m5"),
        price_change_5m_percent=_metric(price_change, "m5"),
        buys_5m=_count(txns_5m.get("buys")),
        sells_5m=_count(txns_5m.get("sells")),
    )

def select_best_token_snapshots(
    pairs: list[dict[str, Any]],
) -> tuple[dict[str, TokenSnapshot], PairFallbackStats]:
    """Select one pair per token and fill only explicitly missing pair fields.

    The selected pair is the highest-liquidity pair with a known liquidity
    value. If the selected pair lacks liquidity or 5m price change, only that
    missing field is taken from another valid Solana pair for the same token.
    No metric is estimated from another field.
    """

    grouped: dict[str, list[TokenSnapshot]] = {}
    for pair in pairs:
        if pair.get("chainId") != SOLANA_CHAIN:
            continue
        snapshot = snapshot_from_pair(pair)
        if snapshot is not None:
            grouped.setdefault(snapshot.address, []).append(snapshot)

    selected_snapshots: dict[str, TokenSnapshot] = {}
    missing_market_cap = 0
    missing_liquidity_before = 0
    missing_liquidity_after = 0
    missing_price_change_before = 0
    missing_price_change_after = 0

    for address, token_pairs in grouped.items():
        selected = max(
            token_pairs,
            key=lambda snapshot: (
                snapshot.liquidity_usd is not None,
                snapshot.liquidity_usd if snapshot.liquidity_usd is not None else -1,
            ),
        )
        liquidity = selected.liquidity_usd
        price_change = selected.price_change_5m_percent

        if selected.market_cap_usd is None:
            missing_market_cap += 1
        if liquidity is None:
            missing_liquidity_before += 1
            liquidity = next(
                (
                    snapshot.liquidity_usd
                    for snapshot in token_pairs
                    if snapshot.liquidity_usd is not None
                ),
                None,
            )
        if price_change is None:
            missing_price_change_before += 1
            price_change = next(
                (
                    snapshot.price_change_5m_percent
                    for snapshot in token_pairs
                    if snapshot.price_change_5m_percent is not None
                ),
                None,
            )

        if liquidity is None:
            missing_liquidity_after += 1
        if price_change is None:
            missing_price_change_after += 1

        selected_snapshots[address] = replace(
            selected,
            liquidity_usd=liquidity,
            price_change_5m_percent=price_change,
        )

    return selected_snapshots, PairFallbackStats(
        missing_market_cap=missing_market_cap,
        missing_liquidity_before=missing_liquidity_before,
        missing_liquidity_after=missing_liquidity_after,
        missing_price_change_before=missing_price_change_before,
        missing_price_change_after=missing_price_change_after,
    )

class FreshnessTracker:
    """Track uninterrupted 7/7 streaks without sending Telegram alerts."""

    def __init__(self, condition_config: dict[str, float]) -> None:
        self._condition_config = condition_config
        self._records: dict[str, list[FreshnessRecord]] = {}
        self._active: dict[str, FreshnessRecord] = {}

    @staticmethod
    def _observation(
        snapshot: TokenSnapshot, observed_at: str
    ) -> FreshnessObservation:
        return FreshnessObservation(
            observed_at=observed_at,
            market_cap_usd=snapshot.market_cap_usd,
            liquidity_usd=snapshot.liquidity_usd,
            volume_5m_usd=snapshot.volume_5m_usd,
            buys_5m=snapshot.buys_5m,
            sells_5m=snapshot.sells_5m,
            buy_sell_ratio_5m=snapshot.buy_sell_ratio_5m,
            price_change_5m_percent=snapshot.price_change_5m_percent,
        )

    @staticmethod
    def _failed_conditions(results: dict[str, bool]) -> str:
        failed = [name for name, passed in results.items() if not passed]
        return ", ".join(failed) if failed else "unknown"

    def _finish(self, record: FreshnessRecord, ended_at: str, reason: str) -> None:
        record.active = False
        record.ended_at = ended_at
        record.end_reason = reason
        self._active.pop(record.address, None)
